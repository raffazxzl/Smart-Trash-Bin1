# tempat-sampah-otomatis
Tempat Sampah Otomatis Berbasis Arduino &amp; Ultrasonic Sensor
